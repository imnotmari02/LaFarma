<?php

$conexion = mysqli_connect("localhost","root","","farmacia") or die("fallas en la conexion");


?>